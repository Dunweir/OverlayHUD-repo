# Repo Monster Bridge

Sends encountered R.E.P.O. monsters to the HTML/OBS overlay server.

Version 0.2.13 removes the in-game HUD, removes bundled RepoSteamNetworking.dll, and syncs level changes to `/api/level`. If the OBS server has not been restarted yet and does not know `/api/level`, it falls back to `/api/state` to reset monsters and update the displayed level.
