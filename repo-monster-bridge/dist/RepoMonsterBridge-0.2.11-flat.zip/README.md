# Repo Monster Bridge

Shows encountered R.E.P.O. monsters inside the game.

The HTML/OBS endpoint is optional and disabled by default in this build.

This package bundles RepoSteamNetworking.dll so the bridge can initialize without TimerMod.

Version 0.2.10 draws the in-game overlay on its own always-on-top Canvas instead of attaching to the game HUD.

Version 0.2.11 runs detection from the plugin's own update loop and enables web overlay sending by default.
