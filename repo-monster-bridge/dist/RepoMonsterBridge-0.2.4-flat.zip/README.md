# Repo Monster Bridge

Shows encountered R.E.P.O. monsters inside the game.

The HTML/OBS endpoint is optional and disabled by default in this build.
