# Repo Monster Bridge

Sends encountered R.E.P.O. monsters to the HTML/OBS overlay server.

Version 0.2.12 removes the in-game HUD, removes bundled RepoSteamNetworking.dll, and syncs level changes to `/api/level` so the web overlay resets monsters and updates the displayed level.
